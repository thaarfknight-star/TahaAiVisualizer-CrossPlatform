"""All 24 visualizer drawing modes, ported from the PySide6 desktop widget
(app/visualizer_widget.py) to the Kivy canvas.

Contract (see app/visualizer.py): each function receives ``viz`` and may only
use ``viz.config``, ``viz.phase``, ``viz._audio_value(i, n, freq)``,
``viz._accent(alpha, t)`` -> (r, g, b, a) floats, ``viz._particles`` and
``viz._bg_rgb()``.

Coordinate flip: the desktop used Qt's top-left origin; Kivy canvas origin is
bottom-left. Every helper below takes Qt-style y (measured from top) and
flips it to ``h - y`` internally, so the ported visual math stays identical.
"""
import math
import random

from kivy.graphics import Color, Ellipse, Line, Mesh, Point, Rectangle, Triangle

__all__ = ["DRAWERS"]


# --------------------------------------------------------------------- #
# small helpers (Qt coords in, Kivy coords out)
# --------------------------------------------------------------------- #
def _seg(viz, x1, y1, x2, y2, h, color, width):
    """Qt drawLine -> Kivy Line with round caps (desktop used RoundCap)."""
    viz.canvas.add(Color(*color))
    viz.canvas.add(
        Line(points=[x1, h - y1, x2, h - y2], width=width, cap="round", joint="round")
    )


def _dot(viz, x, y, r, h, color):
    """Qt drawEllipse(center, r, r) -> Kivy Ellipse."""
    viz.canvas.add(Color(*color))
    viz.canvas.add(Ellipse(pos=(x - r, h - y - r), size=(2 * r, 2 * r)))


# --------------------------------------------------------------------- #
# modes
# --------------------------------------------------------------------- #
def draw_spectrum(viz, w, h, freq):
    cfg = viz.config
    n = max(16, int(cfg.count))
    gap = w / n
    for i in range(n):
        q = viz._audio_value(i, n, freq)
        hh = 5 + q * h * 0.72
        x = i * gap + gap * 0.5
        viz.canvas.add(Color(*viz._accent(0.22 + 0.78 * q, i / n)))
        if cfg.mirror in ("vertical", "both"):
            viz.canvas.add(
                Rectangle(pos=(x - gap * 0.24, h / 2 - hh), size=(gap * 0.48, hh * 2))
            )
        else:
            viz.canvas.add(Rectangle(pos=(x - gap * 0.24, 0), size=(gap * 0.48, hh)))


def draw_bars(viz, w, h, freq):
    cfg = viz.config
    n = max(12, int(cfg.count / 2))
    gap = (w / 2) / n
    for i in range(n):
        q = viz._audio_value(i, n, freq)
        hh = 5 + q * h * 0.7
        color = viz._accent(0.28 + 0.72 * q, i / n)
        for side in (-1, 1):
            x = w / 2 + side * i * gap
            rx = x - gap * 0.65 if side < 0 else x
            viz.canvas.add(Color(*color))
            viz.canvas.add(Rectangle(pos=(rx, h / 2), size=(gap * 0.48, hh)))
            if cfg.mirror in ("vertical", "both"):
                viz.canvas.add(Color(*color))
                viz.canvas.add(
                    Rectangle(pos=(rx, h / 2 - hh), size=(gap * 0.48, hh))
                )


def draw_wave(viz, w, h, freq):
    cfg = viz.config
    step = 3
    prev = None
    x = 0.0
    n_ = max(1.0, w / step)
    wmax = max(1.0, w)
    while x <= w:
        q = viz._audio_value(x / step, n_, freq)
        y = (
            h / 2
            + math.sin(x * 0.027 + viz.phase * 3) * q * h * 0.23
            + math.sin(x * 0.074 - viz.phase * 2) * q * h * 0.08
        )
        if prev is not None:
            _seg(viz, prev[0], prev[1], x, y, h,
                 viz._accent(1.0, x / wmax), cfg.thickness)
        prev = (x, y)
        x += step


def draw_circle(viz, w, h, freq):
    cfg = viz.config
    cx, cy = w / 2, h / 2
    R = min(w, h) * 0.19
    n = max(24, int(cfg.count))
    mwh = min(w, h)
    for i in range(n):
        a = i / n * math.pi * 2
        q = viz._audio_value(i, n, freq)
        rr = R + q * mwh * 0.32
        _seg(viz, cx + math.cos(a) * R, cy + math.sin(a) * R,
             cx + math.cos(a) * rr, cy + math.sin(a) * rr,
             h, viz._accent(0.18 + 0.82 * q, i / n), cfg.thickness)


def draw_radial(viz, w, h, freq):
    cfg = viz.config
    cx, cy = w / 2, h / 2
    R = min(w, h) * 0.28
    n = max(24, int(cfg.count))
    mwh = min(w, h)
    prev = None
    first = None
    for i in range(n + 1):
        a = i / n * math.pi * 2
        r = R + viz._audio_value(i, n, freq) * mwh * 0.24
        pt = (cx + math.cos(a) * r, cy + math.sin(a) * r)
        if first is None:
            first = pt
        if prev is not None:
            _seg(viz, prev[0], prev[1], pt[0], pt[1], h,
                 viz._accent(1.0, i / n), cfg.thickness)
        prev = pt
    if prev is not None and first is not None:
        _seg(viz, prev[0], prev[1], first[0], first[1], h,
             viz._accent(1.0, 1.0), cfg.thickness)


def draw_particles(viz, w, h, freq):
    cfg = viz.config
    q = viz._audio_value(0.25, 1, freq)
    speed = 1 + q * 18 * cfg.sensitivity
    n = len(viz._particles)
    for idx, particle in enumerate(viz._particles):
        particle["x"] += particle["vx"] * speed
        particle["y"] += particle["vy"] * speed
        if particle["x"] < 0 or particle["x"] > 1:
            particle["vx"] *= -1
        if particle["y"] < 0 or particle["y"] > 1:
            particle["vy"] *= -1
        r = 1 + q * 5 * cfg.sensitivity
        _dot(viz, particle["x"] * w, particle["y"] * h, r, h,
             viz._accent(0.10 + q * 0.72, idx / n))


def draw_dots(viz, w, h, freq):
    cfg = viz.config
    n = max(16, int(cfg.count))
    gap = w / n
    r = max(2.0, cfg.thickness * 1.3)
    for i in range(n):
        q = viz._audio_value(i, n, freq)
        x = i * gap + gap * 0.5
        y = h - (10 + q * h * 0.8)          # Qt coords
        color = viz._accent(0.3 + 0.7 * q, i / n)
        _dot(viz, x, y, r, h, color)
        if cfg.mirror in ("vertical", "both"):
            _dot(viz, x, h - y, r, h, color)


def draw_spiral(viz, w, h, freq):
    cfg = viz.config
    cx, cy = w / 2, h / 2
    n = max(60, int(cfg.count) * 2)
    max_r = min(w, h) * 0.46
    prev_pt = None
    for i in range(n):
        t = i / n
        q = viz._audio_value(i, n, freq)
        a = t * math.pi * 10 + viz.phase
        r = t * max_r + q * 22 * cfg.sensitivity
        pt = (cx + math.cos(a) * r, cy + math.sin(a) * r)
        if prev_pt is not None:
            _seg(viz, prev_pt[0], prev_pt[1], pt[0], pt[1], h,
                 viz._accent(0.15 + 0.85 * q, t), cfg.thickness)
        prev_pt = pt


def draw_kaleidoscope(viz, w, h, freq):
    cfg = viz.config
    cx, cy = w / 2, h / 2
    segments = 8
    n = max(16, int(cfg.count) // segments + 8)
    R = min(w, h) * 0.06
    mwh = min(w, h)
    for s in range(segments):
        base_angle = s / segments * math.pi * 2
        prev_pt = None
        for i in range(n):
            q = viz._audio_value(i, n, freq)
            a = base_angle + (i / n) * (math.pi * 2 / segments)
            r = R + q * mwh * 0.42
            pt = (cx + math.cos(a) * r, cy + math.sin(a) * r)
            if prev_pt is not None:
                _seg(viz, prev_pt[0], prev_pt[1], pt[0], pt[1], h,
                     viz._accent(0.2 + 0.8 * q, s / segments), cfg.thickness)
            prev_pt = pt


def draw_bars3d(viz, w, h, freq):
    cfg = viz.config
    n = max(12, int(cfg.count / 1.5))
    gap = w / n
    depth = gap * 0.35
    for i in range(n):
        q = viz._audio_value(i, n, freq)
        hh = 6 + q * h * 0.62
        x = i * gap
        base = viz._accent(0.35 + 0.65 * q, i / n)
        viz.canvas.add(Color(*base))
        viz.canvas.add(Rectangle(pos=(x, 0), size=(gap * 0.55, hh)))
        r, g, b, a = base
        viz.canvas.add(Color(r, g, b, min(1.0, a * 1.35)))
        # top face (Qt top y=h-hh -> Kivy y=hh, Qt top y=h-hh-depth -> Kivy y=hh+depth)
        viz.canvas.add(
            Mesh(
                vertices=[
                    x, hh, 0, 0,
                    x + gap * 0.55, hh, 0, 0,
                    x + gap * 0.55 + depth, hh + depth, 0, 0,
                    x + depth, hh + depth, 0, 0,
                ],
                indices=[0, 1, 2, 3],
                mode="triangle_fan",
            )
        )


def draw_ring(viz, w, h, freq):
    cfg = viz.config
    cx, cy = w / 2, h / 2
    rings = max(6, int(cfg.count / 8))
    max_r = min(w, h) * 0.46
    for i in range(rings):
        t = i / rings
        q = viz._audio_value(i, rings, freq)
        r = 10 + t * max_r + q * 18 * cfg.sensitivity
        viz.canvas.add(Color(*viz._accent(0.15 + 0.7 * q, t)))
        viz.canvas.add(
            Line(
                ellipse=(cx - r, h - cy - r, 2 * r, 2 * r),
                width=max(1.0, cfg.thickness * (0.6 + q)),
            )
        )


def draw_starburst(viz, w, h, freq):
    cfg = viz.config
    cx, cy = w / 2, h / 2
    n = max(16, int(cfg.count / 2))
    R0 = min(w, h) * 0.05
    maxlen = min(w, h) * 0.45
    for i in range(n):
        a = i / n * math.pi * 2 + viz.phase * 0.3
        q = viz._audio_value(i, n, freq)
        r = R0 + q * maxlen
        _seg(viz, cx + math.cos(a) * R0, cy + math.sin(a) * R0,
             cx + math.cos(a) * r, cy + math.sin(a) * r,
             h, viz._accent(0.2 + 0.8 * q, i / n),
             max(1.0, cfg.thickness * (0.4 + q)))


def draw_wavefill(viz, w, h, freq):
    cfg = viz.config
    step = 4
    pts = [(0.0, float(h))]
    x = 0.0
    n_ = max(1.0, w / step)
    while x <= w:
        q = viz._audio_value(x / step, n_, freq)
        y = h / 2 + math.sin(x * 0.02 + viz.phase * 2.4) * q * h * 0.3
        pts.append((x, y))
        x += step
    pts.append((float(w), float(h)))
    verts = []
    for (px, py) in pts:
        verts += [px, h - py, 0, 0]
    viz.canvas.add(Color(*viz._accent(0.5, 0.5)))
    viz.canvas.add(
        Mesh(vertices=verts, indices=list(range(len(pts))), mode="triangle_fan")
    )
    for i in range(1, len(pts) - 1):
        _seg(viz, pts[i][0], pts[i][1], pts[i + 1][0], pts[i + 1][1], h,
             viz._accent(1.0, 0.9), cfg.thickness)


def draw_equalizer(viz, w, h, freq):
    cfg = viz.config
    n = max(12, int(cfg.count / 3))
    gap = w / n
    segs = 14
    seg_h = h / segs * 0.92
    for i in range(n):
        q = viz._audio_value(i, n, freq)
        lit = int(q * segs)
        x = i * gap + gap * 0.12
        color = viz._accent(0.85, i / n)
        dim = viz._accent(0.08, i / n)
        for s in range(segs):
            viz.canvas.add(Color(*(color if s < lit else dim)))
            viz.canvas.add(
                Rectangle(
                    pos=(x, (s + 1) * (h / segs) - seg_h),
                    size=(gap * 0.76, seg_h),
                )
            )


def draw_orbit(viz, w, h, freq):
    cfg = viz.config
    cx, cy = w / 2, h / 2
    n = max(10, int(cfg.count / 4))
    mwh = min(w, h)
    for i in range(n):
        t = i / n
        q = viz._audio_value(i, n, freq)
        r = mwh * (0.1 + t * 0.35) + q * 14
        a = viz.phase * (1 + t) + t * math.pi * 2
        x = cx + math.cos(a) * r
        y = cy + math.sin(a) * r * 0.6
        rad = 2 + q * 8 * cfg.sensitivity
        _dot(viz, x, y, rad, h, viz._accent(0.25 + 0.75 * q, t))


def draw_flower(viz, w, h, freq):
    cfg = viz.config
    cx, cy = w / 2, h / 2
    petals = 6
    n = 160
    R = min(w, h) * 0.05
    maxr = min(w, h) * 0.4
    avg_q = viz._audio_value(n * 0.3, n, freq)
    prev = None
    first = None
    for i in range(n + 1):
        t = i / n
        a = t * math.pi * 2
        q = viz._audio_value(i, n, freq)
        r = R + (maxr * (0.4 + 0.6 * q)) * abs(math.sin(petals * a / 2 + viz.phase))
        pt = (cx + math.cos(a) * r, cy + math.sin(a) * r)
        if first is None:
            first = pt
        if prev is not None:
            _seg(viz, prev[0], prev[1], pt[0], pt[1], h,
                 viz._accent(0.3 + 0.7 * avg_q, t), cfg.thickness)
        prev = pt
    if prev is not None and first is not None:
        _seg(viz, prev[0], prev[1], first[0], first[1], h,
             viz._accent(0.3 + 0.7 * avg_q, 1.0), cfg.thickness)


def draw_fireworks(viz, w, h, freq):
    cfg = viz.config
    bursts = 5
    mwh = min(w, h)
    for b in range(bursts):
        bt = (viz.phase * 0.6 + b / bursts) % 1.0
        bx = w * ((b * 0.618) % 1.0)
        by = h * (0.25 + 0.4 * ((b * 0.382) % 1.0))
        rays = 18
        q = viz._audio_value(b, bursts, freq)
        spread = bt * mwh * 0.22 * (0.6 + q)
        for i in range(rays):
            a = i / rays * math.pi * 2
            x = bx + math.cos(a) * spread
            y = by + math.sin(a) * spread
            alpha = max(0.0, (1.0 - bt) * (0.4 + 0.6 * q))
            rad = max(1.0, cfg.thickness * (1.0 - bt) * 1.5)
            _dot(viz, x, y, rad, h, viz._accent(alpha, i / rays))


def draw_tunnel(viz, w, h, freq):
    cfg = viz.config
    cx, cy = w / 2, h / 2
    rings = 16
    mwh = min(w, h)
    for i in range(rings):
        t = ((i / rings) + (viz.phase * 0.15)) % 1.0
        q = viz._audio_value(i, rings, freq)
        size = t * mwh * (0.9 + q * 0.3)
        alpha = (1.0 - t) * (0.5 + 0.5 * q)
        viz.canvas.add(Color(*viz._accent(alpha, t)))
        viz.canvas.add(
            Line(
                rectangle=(cx - size / 2, h - cy - size / 2, size, size),
                width=cfg.thickness,
            )
        )


def draw_polygon(viz, w, h, freq):
    cfg = viz.config
    cx, cy = w / 2, h / 2
    sides = max(3, min(14, int(cfg.count / 12)))
    R = min(w, h) * 0.3
    mwh = min(w, h)
    prev = None
    first = None
    for i in range(sides + 1):
        t = i / sides
        a = t * math.pi * 2 + viz.phase * 0.5
        q = viz._audio_value(i, sides, freq)
        r = R + q * mwh * 0.22
        pt = (cx + math.cos(a) * r, cy + math.sin(a) * r)
        if first is None:
            first = pt
        if prev is not None:
            _seg(viz, prev[0], prev[1], pt[0], pt[1], h,
                 viz._accent(0.4 + 0.6 * q, t), cfg.thickness)
        prev = pt
    if prev is not None and first is not None:
        q_close = viz._audio_value(sides, sides, freq)
        _seg(viz, prev[0], prev[1], first[0], first[1], h,
             viz._accent(0.4 + 0.6 * q_close, 1.0), cfg.thickness)


def draw_grid(viz, w, h, freq):
    cfg = viz.config
    cols = max(6, int(cfg.count / 6))
    rows = max(4, cols // 2)
    cw, ch = w / cols, h / rows
    for r in range(rows):
        for c in range(cols):
            idx = r * cols + c
            q = viz._audio_value(idx, rows * cols, freq)
            scale = 0.25 + q * 0.75
            cx = c * cw + cw / 2
            cy = r * ch + ch / 2
            sw, sh = cw * 0.8 * scale, ch * 0.8 * scale
            viz.canvas.add(Color(*viz._accent(0.15 + 0.7 * q, c / cols)))
            viz.canvas.add(
                Rectangle(pos=(cx - sw / 2, h - cy - sh / 2), size=(sw, sh))
            )


def draw_vortex(viz, w, h, freq):
    cfg = viz.config
    cx, cy = w / 2, h / 2
    n = max(60, int(cfg.count) * 2)
    max_r = min(w, h) * 0.46
    for arm in (-1, 1):
        prev_pt = None
        for i in range(n):
            t = i / n
            q = viz._audio_value(i, n, freq)
            a = t * math.pi * 8 * arm + viz.phase * 1.4
            r = t * max_r + q * 18 * cfg.sensitivity
            pt = (cx + math.cos(a) * r, cy + math.sin(a) * r)
            if prev_pt is not None:
                _seg(viz, prev_pt[0], prev_pt[1], pt[0], pt[1], h,
                     viz._accent(0.15 + 0.85 * q, t), cfg.thickness)
            prev_pt = pt


def draw_constellation(viz, w, h, freq):
    cfg = viz.config
    n = len(viz._particles)
    pts = []
    for idx, particle in enumerate(viz._particles[:90]):
        q = viz._audio_value(idx, 90, freq)
        x, y = particle["x"] * w, particle["y"] * h
        pts.append((x, y, q))
        rad = 1.2 + q * 3
        _dot(viz, x, y, rad, h, viz._accent(0.35 + 0.65 * q, idx / n))
    max_dist = min(w, h) * 0.14
    for i in range(len(pts)):
        x1, y1, q1 = pts[i]
        for j in range(i + 1, min(i + 6, len(pts))):
            x2, y2, q2 = pts[j]
            d = math.hypot(x1 - x2, y1 - y2)
            if d < max_dist:
                alpha = (1 - d / max_dist) * (0.15 + 0.5 * max(q1, q2))
                viz.canvas.add(Color(*viz._accent(alpha, i / len(pts))))
                viz.canvas.add(Line(points=[x1, h - y1, x2, h - y2], width=1.0))


def draw_ribbon(viz, w, h, freq):
    cfg = viz.config
    layers = 4
    for layer in range(layers):
        lt = layer / layers
        prev = None
        step = 6
        x = 0.0
        n_ = max(1.0, w / step)
        while x <= w:
            q = viz._audio_value(x / step, n_, freq)
            y = (
                h * (0.3 + lt * 0.15)
                + math.sin(x * 0.018 + viz.phase * (1.6 + lt) + lt * 4) * q * h * 0.22
            )
            if prev is not None:
                _seg(viz, prev[0], prev[1], x, y, h,
                     viz._accent(0.2 + 0.6 * q, lt), cfg.thickness)
            prev = (x, y)
            x += step


def draw_ai_generated(viz, w, h, freq):
    """Parametric genome renderer — a UNIQUE visualizer grown from the image's
    DNA (see app.image_ai.analyze_genome on the desktop). Faithful port of the
    desktop _draw_ai_generated: same genes, same seeded anchors, same math."""
    cfg = viz.config
    g = getattr(cfg, "ai_genome", None) or {}
    radialness = float(g.get("radialness", 0.5))
    angularity = float(g.get("angularity", 0.5))
    scatter = float(g.get("scatter", 0.3))
    drift = float(g.get("drift", 0.5))
    pulse = float(g.get("pulse", 1.0))
    symmetry = float(g.get("symmetry", 0.5))
    seed = int(getattr(cfg, "ai_seed", 0))

    n = max(24, int(getattr(cfg, "ai_density", 80)))
    rng = random.Random(seed)
    cx, cy = w / 2, h / 2
    max_r = min(w, h) * 0.46
    max_len = min(w, h) * 0.24

    cols = max(1, int(math.sqrt(n * w / max(1.0, h))))
    rows = max(1, (n + cols - 1) // cols)

    anchors = []
    angles = []
    for i in range(n):
        # circular anchor (golden-ratio spread for organic packing)
        a = (i / max(1, n)) * math.pi * 2 + rng.uniform(-0.25, 0.25)
        rr = max_r * (0.22 + 0.78 * ((i * 0.61803398875) % 1.0))
        ring_x = cx + math.cos(a) * rr
        ring_y = cy + math.sin(a) * rr * 0.92
        # grid anchor
        gx = (i % cols + 0.5) / cols * w
        gy = (i // cols + 0.5) / rows * h
        # blend by radialness, jitter by scatter
        jx = rng.uniform(-1.0, 1.0) * scatter * w * 0.05
        jy = rng.uniform(-1.0, 1.0) * scatter * h * 0.05
        x = gx + (ring_x - gx) * radialness + jx
        y = gy + (ring_y - gy) * radialness + jy
        anchors.append((x, y))
        angles.append(rng.uniform(0, math.pi * 2))

    for i, (x, y) in enumerate(anchors):
        q = viz._audio_value(i, n, freq)
        ang = angles[i] + viz.phase * (0.25 + drift * 1.6)
        length = 3.0 + q * pulse * max_len * cfg.sensitivity
        ex = x + math.cos(ang) * length
        ey = y + math.sin(ang) * length

        width = max(1.0, cfg.thickness * (0.35 + q))
        _seg(viz, x, y, ex, ey, h, viz._accent(0.14 + 0.78 * q, i / max(1, n)), width)
        if symmetry > 0.35:
            mx, mex = 2 * cx - x, 2 * cx - ex
            r_, g_, b_, a_ = viz._accent(0.14 + 0.78 * q, i / max(1, n))
            viz.canvas.add(Color(r_, g_, b_, a_ * symmetry))
            viz.canvas.add(
                Line(points=[mx, h - y, mex, h - ey], width=width,
                     cap="round", joint="round")
            )

        # head: round dot vs sharp shard, morphed by angularity
        r = 1.4 + q * 4.2 * cfg.sensitivity
        head = viz._accent(0.3 + 0.7 * q, i / max(1, n))
        if angularity > 0.55:
            s = r * 1.7
            dx, dy = math.cos(ang) * s, math.sin(ang) * s
            px, py = -dy * 0.5, dx * 0.5
            viz.canvas.add(Color(*head))
            viz.canvas.add(
                Triangle(
                    points=[
                        ex + dx, h - (ey + dy),
                        ex - dx, h - (ey - dy),
                        ex + px, h - (ey + py),
                    ]
                )
            )
        else:
            _dot(viz, ex, ey, r, h, head)


DRAWERS = {
    "spectrum": draw_spectrum,
    "bars": draw_bars,
    "wave": draw_wave,
    "circle": draw_circle,
    "radial": draw_radial,
    "particles": draw_particles,
    "dots": draw_dots,
    "spiral": draw_spiral,
    "kaleidoscope": draw_kaleidoscope,
    "bars3d": draw_bars3d,
    "ring": draw_ring,
    "starburst": draw_starburst,
    "wavefill": draw_wavefill,
    "equalizer": draw_equalizer,
    "orbit": draw_orbit,
    "flower": draw_flower,
    "fireworks": draw_fireworks,
    "tunnel": draw_tunnel,
    "polygon": draw_polygon,
    "grid": draw_grid,
    "vortex": draw_vortex,
    "constellation": draw_constellation,
    "ribbon": draw_ribbon,
    "ai_generated": draw_ai_generated,
}
