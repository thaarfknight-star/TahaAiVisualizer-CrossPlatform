"""Audio backend for the Android port of TahaAi Visualizer.

Sources: microphone (via pyjnius AudioRecord) and a synthetic demo signal.
The FFT pipeline is identical to the desktop engine, so every visualizer
mode behaves the same.

Note: Android does not let third-party apps capture other apps' audio
output, so "system audio" like on the Windows desktop build is not
possible here — the microphone is the live source.
"""
from __future__ import annotations

import threading
from typing import Optional

import numpy as np

try:
    from jnius import autoclass

    _HAS_JNIUS = True
except Exception:  # not on Android / dev machine
    _HAS_JNIUS = False


class AudioEngine:
    FFT_SIZE = 2048

    def __init__(self, samplerate: int = 44100):
        self.samplerate = samplerate
        self.mode = "demo"  # "demo" | "mic"
        self.error: Optional[str] = None

        self._lock = threading.Lock()
        self._latest_block = np.zeros(self.FFT_SIZE, dtype=np.float32)
        self._freq_data = np.zeros(self.FFT_SIZE // 2, dtype=np.float32)
        self._window = np.hanning(self.FFT_SIZE).astype(np.float32)

        self._mic_stop = threading.Event()
        self._mic_thread: Optional[threading.Thread] = None
        self._rec = None

    # ------------------------------------------------------------------ #
    def stop(self) -> None:
        self._stop_mic()
        self.mode = "demo"
        self.error = None

    def start_mic(self) -> bool:
        """Start listening on the microphone. Returns False with
        self.error set when unavailable."""
        if not _HAS_JNIUS:
            self.error = "میکروفون فقط روی گوشی اندرویدی کار می‌کند."
            return False
        self._stop_mic()
        try:
            AudioRecord = autoclass("android.media.AudioRecord")
            MediaRecorder = autoclass("android.media.MediaRecorder")
            AudioFormat = autoclass("android.media.AudioFormat")
            rate = 44100
            minbuf = AudioRecord.getMinBufferSize(
                rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT
            )
            rec = AudioRecord(
                MediaRecorder.AudioSource.MIC,
                rate,
                AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT,
                max(int(minbuf) * 2, 8192),
            )
            if rec.getState() != AudioRecord.STATE_INITIALIZED:
                self.error = "میکروفون آماده نشد."
                return False
            rec.startRecording()
        except Exception as exc:  # noqa: BLE001
            self.error = f"دسترسی به میکروفون ممکن نشد: {exc}"
            return False

        self._rec = rec
        self._mic_stop.clear()
        self._mic_thread = threading.Thread(
            target=self._mic_worker, args=(rec,), daemon=True
        )
        self._mic_thread.start()
        self.mode = "mic"
        self.error = None
        return True

    def _mic_worker(self, rec) -> None:  # noqa: ANN001
        buf = bytearray(4096)
        try:
            while not self._mic_stop.is_set():
                n = rec.read(buf, 0, len(buf))
                if n and n > 0:
                    samples = (
                        np.frombuffer(bytes(buf[: int(n)]), dtype=np.int16).astype(
                            np.float32
                        )
                        / 32768.0
                    )
                    self._push_block(samples)
        except Exception as exc:  # noqa: BLE001
            self.error = f"دریافت صدا قطع شد: {exc}"
        finally:
            for meth in ("stop", "release"):
                try:
                    getattr(rec, meth)()
                except Exception:  # noqa: BLE001
                    pass

    def _stop_mic(self) -> None:
        self._mic_stop.set()
        if self._mic_thread is not None:
            self._mic_thread.join(timeout=1.0)
            self._mic_thread = None
        self._rec = None

    # ------------------------------------------------------------------ #
    # per-frame analysis (same math as the desktop engine)
    # ------------------------------------------------------------------ #
    def compute_frequency_data(self, smoothing: float = 0.72) -> Optional[np.ndarray]:
        """Returns None while in demo mode (caller uses a synthetic curve)."""
        if self.mode == "demo":
            return None

        with self._lock:
            block = self._latest_block.copy()

        windowed = block * self._window
        spectrum = np.abs(np.fft.rfft(windowed))[: self.FFT_SIZE // 2]
        spectrum = spectrum / (self.FFT_SIZE / 2)
        spectrum = np.clip(spectrum * 6.0, 0.0, 1.0).astype(np.float32)

        with self._lock:
            prev = self._freq_data
            smoothed = prev * smoothing + spectrum * (1.0 - smoothing)
            self._freq_data = smoothed
            return smoothed.copy()

    def snapshot(self) -> Optional[np.ndarray]:
        if self.mode == "demo":
            return None
        with self._lock:
            return self._freq_data.copy()

    # ------------------------------------------------------------------ #
    def _push_block(self, chunk: np.ndarray) -> None:
        with self._lock:
            n = len(chunk)
            if n >= self.FFT_SIZE:
                self._latest_block = chunk[-self.FFT_SIZE :].astype(np.float32)
            else:
                self._latest_block = np.concatenate(
                    [self._latest_block[n:], chunk.astype(np.float32)]
                )
