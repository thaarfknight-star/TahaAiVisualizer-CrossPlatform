"""Kivy visualizer canvas widget — Android port of the PySide6 widget.

Redraws every frame on the Kivy canvas. All 24 drawing modes live in
app/viz_modes.py; each receives this widget (``viz``) and may only use:

  viz.config                  Config
  viz.phase                   float, advances every frame
  viz._audio_value(i, n, freq) -> float 0..1
  viz._accent(alpha, t=0.0)   -> (r, g, b, a) floats for Kivy Color
  viz._particles              list of {x, y, vx, vy} in 0..1
  viz._bg_rgb()               -> (r, g, b) base background color

Kivy canvas origin is bottom-left (Qt was top-left); the mode functions
handle the flip themselves.
"""
from __future__ import annotations

import random
from typing import Optional, Tuple

from kivy.clock import Clock
from kivy.core.image import Image as CoreImage
from kivy.graphics import Color, Rectangle
from kivy.uix.widget import Widget

from . import viz_modes
from .audio_engine import AudioEngine
from .config import Config


def _hex_to_rgb(h: str) -> Tuple[float, float, float]:
    h = h.lstrip("#")
    return tuple(int(h[i : i + 2], 16) / 255.0 for i in (0, 2, 4))


class VisualizerWidget(Widget):
    def __init__(self, config: Config, audio: AudioEngine, **kwargs):
        super().__init__(**kwargs)
        self.config = config
        self.audio = audio
        self.phase = 0.0
        self._particles = [
            {
                "x": random.random(),
                "y": random.random(),
                "vx": (random.random() - 0.5) * 0.006,
                "vy": (random.random() - 0.5) * 0.006,
            }
            for _ in range(180)
        ]
        self._bg_texture = None
        self._tick_ev = None
        self.apply_fps(config.fps)

    # ------------------------------------------------------------------ #
    def apply_fps(self, fps: int) -> None:
        if self._tick_ev is not None:
            self._tick_ev.cancel()
        self._tick_ev = Clock.schedule_interval(self._tick, 1.0 / max(1, int(fps)))

    def set_background_image(self, path: str) -> None:
        self._bg_texture = None
        if path:
            try:
                self._bg_texture = CoreImage(path).texture
            except Exception:  # noqa: BLE001
                self._bg_texture = None

    # ------------------------------------------------------------------ #
    def _tick(self, dt: float) -> None:
        self.phase += 0.018
        self.audio.compute_frequency_data(self.config.smoothing)
        self._redraw()

    def _redraw(self) -> None:
        self.canvas.clear()
        w, h = self.width, self.height
        if w < 2 or h < 2:
            return
        freq = self.audio.snapshot()
        drawer = viz_modes.DRAWERS.get(self.config.mode) or viz_modes.DRAWERS["spectrum"]
        with self.canvas:
            self._draw_background(w, h)
            drawer(self, w, h, freq)

    # ------------------------------------------------------------------ #
    # helpers (the contract used by viz_modes)
    # ------------------------------------------------------------------ #
    def _audio_value(self, index: float, total: float, freq) -> float:
        cfg = self.config
        if freq is not None and len(freq):
            bin_index = int((index / max(1.0, total)) ** 1.7 * len(freq) * 0.8)
            bin_index = min(max(bin_index, 0), len(freq) - 1)
            v = float(freq[bin_index])
            if cfg.bass_boost and bin_index < len(freq) * 0.12:
                v *= 1.25
            return min(1.0, v * cfg.sensitivity)
        # deterministic demo signal, independent from real audio
        import math

        return (
            0.08
            + 0.44 * math.sin(self.phase * 2.1 + index * 0.47) ** 2
            + 0.18 * math.sin(self.phase * 4.2 + index * 0.11) ** 2
        )

    def _color_at(self, t: float, alpha: float = 1.0) -> Tuple[float, float, float, float]:
        cfg = self.config
        colors = cfg.gradient_colors
        if cfg.color_mode == "gradient" and colors and len(colors) >= 2:
            t = max(0.0, min(1.0, t))
            n = len(colors)
            seg = t * (n - 1)
            i = min(int(seg), n - 2)
            lt = seg - i
            c1, c2 = _hex_to_rgb(colors[i]), _hex_to_rgb(colors[i + 1])
            r = c1[0] + (c2[0] - c1[0]) * lt
            g = c1[1] + (c2[1] - c1[1]) * lt
            b = c1[2] + (c2[2] - c1[2]) * lt
        else:
            r, g, b = _hex_to_rgb(cfg.accent)
        a = max(0.0, min(1.0, cfg.opacity * alpha))
        return (r, g, b, a)

    def _accent(self, alpha: float, t: float = 0.0) -> Tuple[float, float, float, float]:
        return self._color_at(t, alpha)

    def _bg_rgb(self) -> Tuple[float, float, float]:
        return (9 / 255.0, 9 / 255.0, 15 / 255.0)

    # ------------------------------------------------------------------ #
    def _draw_background(self, w: float, h: float) -> None:
        cfg = self.config
        if cfg.background == "image" and self._bg_texture is not None:
            tex = self._bg_texture
            tw, th = tex.width, tex.height
            scale = max(w / max(1, tw), h / max(1, th))
            dw, dh = tw * scale, th * scale
            Color(1, 1, 1, 1)
            Rectangle(
                texture=tex, pos=((w - dw) / 2, (h - dh) / 2), size=(dw, dh)
            )
            dim = max(0.0, min(1.0, cfg.image_dim))
            Color(9 / 255.0, 9 / 255.0, 15 / 255.0, dim)
            Rectangle(pos=(0, 0), size=(w, h))
            return

        r, g, b = self._bg_rgb()
        Color(r, g, b, 1)
        Rectangle(pos=(0, 0), size=(w, h))
        if cfg.background == "gradient":
            # radial-ish accent glow approximated with concentric rects
            ar, ag, ab = _hex_to_rgb(cfg.accent)
            for i in range(6, 0, -1):
                f = i / 6.0
                Color(ar, ag, ab, 0.055 * (1.0 - f) + 0.008)
                rw, rh = w * f, h * f
                Rectangle(pos=((w - rw) / 2, (h - rh) / 2), size=(rw, rh))
