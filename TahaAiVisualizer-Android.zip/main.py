"""TahaAi Visualizer — Android (Kivy) edition.

Same visualizer as the Python/PySide6 desktop app, with all features:
24 visualizer modes, background image, and the Image AI:
palette/mood scan + the unique per-image visual genome (AI Generated mode).

Audio sources on Android: microphone or the built-in demo signal.
(Android does not allow third-party apps to capture other apps' audio.)
"""
from __future__ import annotations

import os

import numpy as np

from kivy.app import App
from kivy.clock import Clock
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button
from kivy.uix.label import Label
from kivy.uix.slider import Slider
from kivy.uix.spinner import Spinner
from kivy.utils import platform

from app.audio_engine import AudioEngine
from app.config import Config, MODES
from app.visualizer import VisualizerWidget

try:
    import arabic_reshaper
    from bidi.algorithm import get_display

    def fa(text: str) -> str:
        return get_display(arabic_reshaper.reshape(str(text)))

except Exception:  # pragma: no cover - fallback when libs missing

    def fa(text: str) -> str:
        return str(text)


FONT = os.path.join(os.path.dirname(__file__), "assets", "fonts", "Vazirmatn-Regular.ttf")

FA_MODE_NAMES = {
    "spectrum": "طیف",
    "bars": "میله‌های آینه‌ای",
    "wave": "موج",
    "circle": "دایره‌ای",
    "radial": "شعاعی",
    "particles": "ذرات",
    "dots": "ماتریس نقطه‌ای",
    "spiral": "مارپیچ",
    "kaleidoscope": "کالیدوسکوپ",
    "bars3d": "میله‌های پرسپکتیو",
    "ring": "حلقه‌های پالس",
    "starburst": "انفجار ستاره‌ای",
    "wavefill": "موج توپر",
    "equalizer": "اکولایزر LED",
    "orbit": "مدارها",
    "flower": "شکوفه",
    "fireworks": "آتش‌بازی",
    "tunnel": "تونل",
    "polygon": "چندضلعی پالس",
    "grid": "شبکه واکنش‌گرا",
    "vortex": "گرداب",
    "constellation": "صورت فلکی",
    "ribbon": "روبان",
    "ai_generated": "ساخته هوش مصنوعی",
}


def _request_android_permissions() -> None:
    if platform != "android":
        return
    try:
        from android.permissions import Permission, request_permissions

        request_permissions(
            [
                Permission.RECORD_AUDIO,
                Permission.READ_EXTERNAL_STORAGE,
                Permission.WRITE_EXTERNAL_STORAGE,
            ]
        )
    except Exception:  # noqa: BLE001
        pass


class TahaAiApp(App):
    title = "TahaAi Visualizer"

    def build(self):
        _request_android_permissions()
        self.cfg = self._load_config()
        self.audio = AudioEngine()

        root = BoxLayout(orientation="vertical", spacing=0)

        self.viz = VisualizerWidget(self.cfg, self.audio, size_hint_y=0.70)
        if self.cfg.background_image:
            self.viz.set_background_image(self.cfg.background_image)
        root.add_widget(self.viz)

        panel = BoxLayout(
            orientation="vertical", size_hint_y=0.30, padding=8, spacing=6
        )

        # row 1: mode spinner + mic toggle ------------------------------ #
        row1 = BoxLayout(spacing=6, size_hint_y=0.28)
        self.mode_spinner = Spinner(
            text=fa(FA_MODE_NAMES.get(self.cfg.mode, self.cfg.mode)),
            values=[fa(FA_MODE_NAMES.get(k, k)) for k, _ in MODES],
            font_name=FONT,
            size_hint_x=0.62,
        )
        self.mode_spinner.bind(text=self.on_mode_chosen)
        self.mic_btn = Button(text=fa("میکروفون: خاموش"), font_name=FONT, size_hint_x=0.38)
        self.mic_btn.bind(on_press=self.toggle_mic)
        row1.add_widget(self.mode_spinner)
        row1.add_widget(self.mic_btn)
        panel.add_widget(row1)

        # row 2: image actions ------------------------------------------ #
        row2 = BoxLayout(spacing=6, size_hint_y=0.28)
        self.img_btn = Button(text=fa("عکس پس‌زمینه"), font_name=FONT)
        self.img_btn.bind(on_press=self.pick_background_image)
        self.scan_btn = Button(text=fa("اسکن هوشمند تصویر"), font_name=FONT)
        self.scan_btn.bind(on_press=self.pick_scan_image)
        row2.add_widget(self.img_btn)
        row2.add_widget(self.scan_btn)
        panel.add_widget(row2)

        # row 3: sliders ------------------------------------------------- #
        row3 = BoxLayout(spacing=10, size_hint_y=0.30)
        row3.add_widget(self._slider_col("حساسیت", 0.2, 2.5, self.cfg.sensitivity,
                                        self.on_sensitivity))
        row3.add_widget(self._slider_col("ضخامت", 1.0, 8.0, self.cfg.thickness,
                                        self.on_thickness))
        row3.add_widget(self._slider_col("نرمی", 0.0, 0.95, self.cfg.smoothing,
                                        self.on_smoothing))
        panel.add_widget(row3)

        # status line ----------------------------------------------------- #
        self.status_label = Label(
            text=fa("حالت نمایشی: سیگنال نمایشی"),
            font_name=FONT,
            font_size="13sp",
            size_hint_y=0.14,
            halign="center",
        )
        panel.add_widget(self.status_label)

        root.add_widget(panel)
        return root

    # ------------------------------------------------------------------ #
    def _slider_col(self, title, lo, hi, value, callback):
        col = BoxLayout(orientation="vertical", spacing=2)
        col.add_widget(Label(text=fa(title), font_name=FONT, font_size="12sp",
                             size_hint_y=0.4))
        s = Slider(min=lo, max=hi, value=value, size_hint_y=0.6)
        s.bind(value=callback)
        col.add_widget(s)
        return col

    def on_sensitivity(self, _s, v):
        self.cfg.sensitivity = float(v)

    def on_thickness(self, _s, v):
        self.cfg.thickness = float(v)

    def on_smoothing(self, _s, v):
        self.cfg.smoothing = float(v)

    # ------------------------------------------------------------------ #
    def on_mode_chosen(self, _spinner, text):
        for key, _label in MODES:
            if fa(FA_MODE_NAMES.get(key, key)) == text:
                self.cfg.mode = key
                break
        self._say(fa("حالت: ") + text)

    def set_mode(self, key: str) -> None:
        self.cfg.mode = key
        self.mode_spinner.text = fa(FA_MODE_NAMES.get(key, key))

    # ------------------------------------------------------------------ #
    def toggle_mic(self, _btn):
        if self.audio.mode == "mic":
            self.audio.stop()
            self.mic_btn.text = fa("میکروفون: خاموش")
            self._say(fa("حالت نمایشی: سیگنال نمایشی"))
        else:
            if self.audio.start_mic():
                self.mic_btn.text = fa("میکروفون: روشن")
                self._say(fa("در حال شنیدن از میکروفون…"))
            else:
                self._say(fa(self.audio.error or "خطا"))

    # ------------------------------------------------------------------ #
    def _pick_image(self, callback):
        try:
            from plyer import filechooser

            filechooser.open_file(
                on_selection=callback,
                filters=[("Images", "*.png", "*.jpg", "*.jpeg", "*.webp")],
            )
        except Exception as exc:  # noqa: BLE001
            self._say(fa(f"انتخاب فایل ممکن نشد: {exc}"))

    def pick_background_image(self, _btn):
        self._pick_image(self._on_background_picked)

    def _on_background_picked(self, selection):
        if not selection:
            return
        path = selection[0]
        self.cfg.background = "image"
        self.cfg.background_image = path
        self.viz.set_background_image(path)
        self._say(fa("عکس پس‌زمینه تنظیم شد"))

    # ---- Image AI ------------------------------------------------------ #
    def pick_scan_image(self, _btn):
        self._pick_image(self._on_scan_picked)

    def _on_scan_picked(self, selection):
        if not selection:
            return
        path = selection[0]
        self._say(fa("در حال اسکن هوشمند…"))
        Clock.schedule_once(lambda _dt: self._run_ai_scan(path), 0.05)

    def _run_ai_scan(self, path: str) -> None:
        try:
            from PIL import Image as PILImage

            from app.image_ai import analyze_genome, analyze_image, genome_to_dict

            pixels = np.array(PILImage.open(path).convert("RGB"))
            result = analyze_image(pixels, k=5)
            genome = analyze_genome(pixels)
        except Exception as exc:  # noqa: BLE001
            self._say(fa(f"خطا در تحلیل تصویر: {exc}"))
            return

        cfg = self.cfg
        cfg.ai_colors = list(result.palette)
        cfg.ai_mood = result.mood_fa
        cfg.image_dim = result.overlay_dim
        cfg.color_mode = "gradient"
        cfg.gradient_colors = list(result.palette[:4])
        cfg.accent = result.palette[0]
        cfg.background = "image"
        cfg.background_image = path
        self.viz.set_background_image(path)

        cfg.ai_genome = genome_to_dict(genome)
        cfg.ai_seed = genome.seed
        cfg.ai_density = genome.density
        self.set_mode("ai_generated")

        g = cfg.ai_genome
        dna = (f"شعاعی {int(g['radialness']*100)}٪ • تیز {int(g['angularity']*100)}٪ • "
               f"پراکنده {int(g['scatter']*100)}٪")
        self._say(fa(f"ویژولایزر یکتا: {genome.name_fa} — {dna}"))

    # ------------------------------------------------------------------ #
    def _say(self, text: str) -> None:
        self.status_label.text = text

    # ------------------------------------------------------------------ #
    def _config_path(self) -> str:
        return os.path.join(self.user_data_dir, "config.json")

    def _load_config(self) -> Config:
        path = self._config_path()
        if os.path.exists(path):
            try:
                return Config.load(path)
            except Exception:  # noqa: BLE001
                pass
        return Config()

    def on_stop(self):
        try:
            self.audio.stop()
            self.cfg.save(self._config_path())
        except Exception:  # noqa: BLE001
            pass


if __name__ == "__main__":
    TahaAiApp().run()
