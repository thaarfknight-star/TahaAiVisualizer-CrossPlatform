[app]

# (str) Title of your application
title = TahaAi Visualizer

# (str) Package name
package.name = tahaai_visualizer

# (str) Package domain (needed for android/ios packaging)
package.domain = org.tahaai

# (str) Source code where the main.py live
source.dir = .

# (list) Source files to include (let empty to include not the exclusion)
source.include_exts = py,png,jpg,jpeg,webp,ttf,json

# (str) Application version
version = 1.0.0

# (list) Application requirements
# kivy: UI framework | numpy: FFT + Image AI | pillow: image loading
# plyer: file chooser | pyjnius: microphone (AudioRecord)
# arabic-reshaper + python-bidi: correct Persian text shaping in Kivy
requirements = python3,kivy,numpy,pillow,plyer,pyjnius,arabic-reshaper,python-bidi

# (str) Supported orientations: landscape, portrait, sensor, all ...
orientation = all

# (bool) Indicate if the application should be fullscreen or not
fullscreen = 0

# (str) Android entry point / service names are auto-detected from main.py

# (list) Android permissions
android.permissions = RECORD_AUDIO,READ_EXTERNAL_STORAGE,WRITE_EXTERNAL_STORAGE,READ_MEDIA_IMAGES

# (int) Target Android API (33 = Android 13)
android.api = 33

# (bool) Auto-accept Android SDK licenses in CI (sdkmanager would otherwise
# skip build-tools and the build fails with "Aidl not found")
android.accept_sdk_license = True

# (int) Minimum Android API
android.minapi = 24

# (str) Android NDK version
android.ndk = 25b

# (list) Android architectures: arm64-v8a covers all modern phones and
# halves the CI build time. Add armeabi-v7a if you need 32-bit devices.
android.archs = arm64-v8a

# (str) Path to the app icon (512x512 png)
icon.filename = assets/icon.png

# (str) Android app theme: Dark or Light
android.theme = Dark

[buildozer]

# (int) Log level (0 = error only, 1 = info, 2 = debug)
log_level = 2

# (int) Display warning if buildozer is run as root (0 = False, 1 = True)
warn_on_root = 1
